package ee.academy.projektplus.quiz1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Quiz1Application {

	public static void main(String[] args) {
		SpringApplication.run(Quiz1Application.class, args);
	}

}
